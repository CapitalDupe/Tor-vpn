# Tor Proxy Chain VPN (Android)

A per-device VPN app that routes traffic through:
`your app` → `local SOCKS5 chain relay` → `proxy 1` → `proxy 2` → `proxy 3` → `Tor (via Orbot)`

You choose how many hops to use and in what order, including 0 (no chain, direct)
or Tor-only.

## Architecture

- **MainActivity** — UI to add/remove proxy hops (SOCKS5, HTTP, HTTPS) and connect/disconnect.
- **ProxyConfig.kt** — data model + persistence for your saved chain.
- **ProxyChainSocksServer.kt** — a small local SOCKS5 server (127.0.0.1:1080) that
  performs the actual hop-by-hop relaying: SOCKS5 and HTTP CONNECT handshakes,
  chained in order. Fully working, pure Kotlin, no native code.
- **OrbotManager.kt** — talks to the [Orbot](https://orbot.app) app via its public,
  documented broadcast intent (`org.torproject.android.START_TOR`) and its default
  SOCKS port (127.0.0.1:9050). We don't bundle a Tor binary — Orbot already is one,
  it's open source, and reusing it means you get Tor's official, audited packaging.
- **TorVpnService.kt** — opens the Android `VpnService` tun interface and hands the
  raw IP traffic to a tun→SOCKS5 converter pointed at the local chain server.

## One piece you need to add yourself: tun2socks

Turning raw IP packets from the tun interface into SOCKS5 connections needs a small
userspace network stack. Writing a correct one from scratch is its own large project,
so this app is wired to use the open-source, actively maintained
**[hev-socks5-tunnel](https://github.com/heiher/hev-socks5-tunnel)** for that job.

Setup:
1. Download the prebuilt binaries for each Android ABI from its
   [GitHub releases](https://github.com/heiher/hev-socks5-tunnel/releases)
   (or build from source with the NDK — instructions in that repo).
2. Place them at:
   ```
   app/src/main/jniLibs/arm64-v8a/libhev-socks5-tunnel.so
   app/src/main/jniLibs/armeabi-v7a/libhev-socks5-tunnel.so
   app/src/main/jniLibs/x86_64/libhev-socks5-tunnel.so
   ```
3. Android will place these under `applicationInfo.nativeLibraryDir` at install
   time, which is exactly where `TorVpnService.launchTun2Socks()` looks for it.

Alternative: swap in any other tun2socks implementation (e.g. `badvpn-tun2socks`,
`go-tun2socks`) — just point it at `127.0.0.1:1080` and give it the tun fd.

## Using Tor

1. Install [Orbot](https://orbot.app) (F-Droid, Play Store, or GitHub releases) —
   it's the official Tor Project Android app.
2. In this app, toggle "Include Tor as final hop" before connecting. This app
   starts Orbot and appends a hop that forwards into Orbot's SOCKS port.
3. Your chain becomes: `your proxies... → Tor network → destination`.

## Adding your own private proxies

Tap **"Add private / custom proxy"** and enter host, port, type (SOCKS5 / HTTP /
HTTPS), and optional username/password. It's added to the chain immediately in
the order you add hops — drag-to-reorder is a natural next feature to add to the
`RecyclerView` if you want it.

## Free / open-source proxy lists

The "Add free open-source proxy preset" button is left as a stub on purpose —
public proxy lists rotate constantly, and many free proxies are unreliable, slow,
or actively malicious (logging/injecting into your traffic). Wire it to a source
you actually trust, or skip it and rely on Tor + your own private proxies, which
is the safer default.

## Building

Open this folder in Android Studio (Koala+ recommended), let Gradle sync, add the
`jniLibs` binaries above, then Run. Minimum SDK 26.

## Notes on scope / what's real here

- The proxy chain relay (SOCKS5 + HTTP CONNECT hop negotiation) is complete,
  working Kotlin — no stubs.
- The Orbot integration uses Orbot's real, documented intent API.
- The only external dependency you must add by hand is the tun2socks native
  binary, because bundling/cross-compiling native code for 3 CPU architectures
  isn't something that can be done without an Android NDK toolchain, which this
  build environment doesn't have. That step is a five-minute download, not new
  code to write.
