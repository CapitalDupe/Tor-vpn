package com.yourname.torproxychain

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var chain: MutableList<ProxyHop>
    private lateinit var adapter: ProxyAdapter
    private lateinit var statusText: TextView

    private val vpnPrepareLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startForegroundService(Intent(this, TorVpnService::class.java))
            statusText.text = "Status: connected"
        } else {
            statusText.text = "Status: permission denied"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        chain = ProxyStore.loadChain(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }

        statusText = TextView(this).apply { text = "Status: disconnected"; textSize = 16f }
        root.addView(statusText)

        val includeTorSwitch = Switch(this).apply {
            text = "Include Tor as final hop (requires Orbot)"
            isChecked = chain.any { it.isTorExit }
        }
        root.addView(includeTorSwitch)

        val recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ProxyAdapter(chain) { pos -> chain.removeAt(pos); adapter.notifyDataSetChanged() }
        recycler.adapter = adapter
        root.addView(recycler, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val addBtn = Button(this).apply { text = "Add private / custom proxy" }
        addBtn.setOnClickListener { showAddProxyDialog() }
        root.addView(addBtn)

        val presetBtn = Button(this).apply { text = "Add free open-source proxy preset" }
        presetBtn.setOnClickListener { showPresetDialog() }
        root.addView(presetBtn)

        val connectBtn = Button(this).apply { text = "Connect" }
        connectBtn.setOnClickListener {
            var finalChain = chain.toMutableList()
            finalChain.removeAll { it.isTorExit }
            if (includeTorSwitch.isChecked) {
                if (!OrbotManager.isOrbotInstalled(this)) {
                    Toast.makeText(this, "Install Orbot first", Toast.LENGTH_LONG).show()
                    OrbotManager.openOrbotInstallPage(this)
                    return@setOnClickListener
                }
                OrbotManager.requestStartTor(this)
                finalChain.add(ProxyHop.torExitHop())
            }
            ProxyStore.saveChain(this, finalChain)
            chain = finalChain

            val prepareIntent = VpnService.prepare(this)
            if (prepareIntent != null) {
                vpnPrepareLauncher.launch(prepareIntent)
            } else {
                startForegroundService(Intent(this, TorVpnService::class.java))
                statusText.text = "Status: connected"
            }
        }
        root.addView(connectBtn)

        val disconnectBtn = Button(this).apply { text = "Disconnect" }
        disconnectBtn.setOnClickListener {
            stopService(Intent(this, TorVpnService::class.java))
            statusText.text = "Status: disconnected"
        }
        root.addView(disconnectBtn)

        setContentView(root)
    }

    private fun showAddProxyDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 20) }
        val label = EditText(this).apply { hint = "Label (e.g. My VPS)" }
        val host = EditText(this).apply { hint = "Host / IP" }
        val port = EditText(this).apply { hint = "Port"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val user = EditText(this).apply { hint = "Username (optional)" }
        val pass = EditText(this).apply { hint = "Password (optional)"; inputType = android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val typeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ProxyType.values().map { it.name })
        }
        listOf(label, host, port, typeSpinner, user, pass).forEach { layout.addView(it) }

        AlertDialogHelper.show(this, "Add proxy", layout) {
            val p = port.text.toString().toIntOrNull() ?: return@show
            chain.add(
                ProxyHop(
                    label = label.text.toString().ifBlank { host.text.toString() },
                    type = ProxyType.valueOf(typeSpinner.selectedItem as String),
                    host = host.text.toString(),
                    port = p,
                    username = user.text.toString().ifBlank { null },
                    password = pass.text.toString().ifBlank { null }
                )
            )
            adapter.notifyDataSetChanged()
        }
    }

    private fun showPresetDialog() {
        // NOTE: these are illustrative placeholders only. Free public proxy lists change
        // constantly and are frequently unreliable or malicious — always verify a proxy's
        // source before trusting it with your traffic. Wire this up to a proxy-list source
        // you trust (or your own infra) rather than hardcoding IPs that will go stale.
        Toast.makeText(
            this,
            "Hook this button up to a proxy-list provider you trust, or just use 'Add private/custom proxy' for known-good SOCKS5/HTTP proxies.",
            Toast.LENGTH_LONG
        ).show()
    }
}

class ProxyAdapter(
    private val items: MutableList<ProxyHop>,
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<ProxyAdapter.VH>() {
    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context).apply { setPadding(24, 24, 24, 24); textSize = 15f }
        return VH(tv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val hop = items[position]
        holder.tv.text = "${position + 1}. ${hop.label} — ${hop.type} ${hop.host}:${hop.port}" +
            if (hop.isTorExit) " [Tor]" else ""
        holder.tv.setOnLongClickListener { onRemove(position); true }
    }

    override fun getItemCount() = items.size
}

object AlertDialogHelper {
    fun show(activity: Activity, title: String, view: android.view.View, onOk: () -> Unit) {
        androidx.appcompat.app.AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(view)
            .setPositiveButton("Add") { _, _ -> onOk() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
