package com.yourname.torproxychain

import org.json.JSONArray
import org.json.JSONObject

enum class ProxyType { SOCKS5, HTTP, HTTPS }

/**
 * One hop in the chain. Order in the list = order of the chain.
 * A hop with isTorExit=true means "hand the connection to Orbot's Tor SOCKS port"
 * instead of connecting out to host/port directly. This is normally the LAST hop.
 */
data class ProxyHop(
    val label: String,
    val type: ProxyType,
    val host: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val isTorExit: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("label", label)
        put("type", type.name)
        put("host", host)
        put("port", port)
        put("username", username ?: "")
        put("password", password ?: "")
        put("isTorExit", isTorExit)
    }

    companion object {
        fun fromJson(o: JSONObject): ProxyHop = ProxyHop(
            label = o.getString("label"),
            type = ProxyType.valueOf(o.getString("type")),
            host = o.getString("host"),
            port = o.getInt("port"),
            username = o.optString("username").ifBlank { null },
            password = o.optString("password").ifBlank { null },
            isTorExit = o.optBoolean("isTorExit", false)
        )

        fun torExitHop(orbotSocksPort: Int = 9050): ProxyHop = ProxyHop(
            label = "Tor (via Orbot)",
            type = ProxyType.SOCKS5,
            host = "127.0.0.1",
            port = orbotSocksPort,
            isTorExit = true
        )
    }
}

/** Simple persistence for the user's saved chain, stored in SharedPreferences as JSON. */
object ProxyStore {
    private const val PREFS = "proxy_store"
    private const val KEY_CHAIN = "chain"

    fun loadChain(ctx: android.content.Context): MutableList<ProxyHop> {
        val prefs = ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_CHAIN, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { ProxyHop.fromJson(arr.getJSONObject(it)) }.toMutableList()
    }

    fun saveChain(ctx: android.content.Context, chain: List<ProxyHop>) {
        val arr = JSONArray()
        chain.forEach { arr.put(it.toJson()) }
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putString(KEY_CHAIN, arr.toString()).apply()
    }
}
