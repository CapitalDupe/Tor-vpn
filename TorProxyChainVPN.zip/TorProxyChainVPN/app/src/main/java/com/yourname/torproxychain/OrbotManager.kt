package com.yourname.torproxychain

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Talks to the Orbot app (org.torproject.android) via its published, open-source
 * intent API instead of bundling a Tor binary ourselves. Orbot must be installed
 * from F-Droid / Play Store / GitHub releases.
 *
 * Orbot's default SOCKS5 port is 9050 and its HTTP proxy port is 8118, both
 * configurable inside Orbot's own settings.
 */
object OrbotManager {
    const val ORBOT_PACKAGE = "org.torproject.android"
    const val DEFAULT_SOCKS_PORT = 9050

    fun isOrbotInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(ORBOT_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Ask Orbot to start Tor (shows Orbot's own connect UI/notification). */
    fun requestStartTor(ctx: Context) {
        val intent = Intent("org.torproject.android.START_TOR")
        intent.setPackage(ORBOT_PACKAGE)
        ctx.sendBroadcast(intent)
    }

    /** Deep-link the user to install Orbot if it's missing. */
    fun openOrbotInstallPage(ctx: Context) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = android.net.Uri.parse("https://guardianproject.info/apps/org.torproject.android/")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }
}
