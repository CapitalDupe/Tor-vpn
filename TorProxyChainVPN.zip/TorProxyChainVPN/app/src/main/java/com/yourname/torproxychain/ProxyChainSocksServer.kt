package com.yourname.torproxychain

import android.util.Base64
import android.util.Log
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A local SOCKS5 server. The tun2socks native component (hev-socks5-tunnel) forwards
 * all device traffic here. For every incoming connection we relay it through the
 * user-configured proxy chain (proxy1 -> proxy2 -> proxy3 -> ... -> optional Tor exit).
 *
 * Only CONNECT (TCP) is implemented, which covers the overwhelming majority of app
 * traffic (HTTP/HTTPS/most everything). UDP association is not implemented.
 */
class ProxyChainSocksServer(
    private val listenPort: Int,
    private val getChain: () -> List<ProxyHop>,
    private val protectSocket: (Socket) -> Boolean, // VpnService.protect() so we don't loop traffic back into the tunnel
    private val onLog: (String) -> Unit = {}
) {
    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        if (running.getAndSet(true)) return
        pool.execute {
            try {
                serverSocket = ServerSocket(listenPort, 128, InetSocketAddress("127.0.0.1", 0).address)
                onLog("Local SOCKS5 chain server listening on 127.0.0.1:$listenPort")
                while (running.get()) {
                    val client = serverSocket?.accept() ?: break
                    pool.execute { handleClient(client) }
                }
            } catch (e: Exception) {
                onLog("Server stopped: ${e.message}")
            }
        }
    }

    fun stop() {
        running.set(false)
        try { serverSocket?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun handleClient(client: Socket) {
        try {
            client.soTimeout = 15000
            val input = DataInputStream(client.getInputStream())
            val output = DataOutputStream(client.getOutputStream())

            // --- SOCKS5 handshake with the local app that's forwarding traffic to us ---
            val ver = input.readByte().toInt()
            if (ver != 0x05) { client.close(); return }
            val nMethods = input.readByte().toInt() and 0xFF
            val methods = ByteArray(nMethods)
            input.readFully(methods)
            output.write(byteArrayOf(0x05, 0x00)) // no-auth
            output.flush()

            val verReq = input.readByte().toInt()
            val cmd = input.readByte().toInt()
            input.readByte() // reserved
            val atyp = input.readByte().toInt()
            val destHost: String
            when (atyp) {
                0x01 -> { // IPv4
                    val addr = ByteArray(4); input.readFully(addr)
                    destHost = addr.joinToString(".") { (it.toInt() and 0xFF).toString() }
                }
                0x03 -> { // domain name
                    val len = input.readByte().toInt() and 0xFF
                    val addr = ByteArray(len); input.readFully(addr)
                    destHost = String(addr, Charsets.US_ASCII)
                }
                0x04 -> { // IPv6 - not handled, reject
                    replySocksFailure(output); client.close(); return
                }
                else -> { replySocksFailure(output); client.close(); return }
            }
            val destPort = input.readUnsignedShort()

            if (cmd != 0x01) { // only CONNECT supported
                replySocksFailure(output); client.close(); return
            }

            val chain = getChain()
            val upstream = try {
                connectThroughChain(chain, destHost, destPort)
            } catch (e: Exception) {
                onLog("Chain connect failed for $destHost:$destPort -> ${e.message}")
                replySocksFailure(output); client.close(); return
            }

            // success reply
            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            pipe(client.getInputStream(), upstream.getOutputStream())
            pipe(upstream.getInputStream(), client.getOutputStream())

        } catch (e: Exception) {
            onLog("Client handling error: ${e.message}")
            try { client.close() } catch (_: Exception) {}
        }
    }

    /** Opens a socket to the first hop, then tunnels CONNECT requests hop by hop to the final destination. */
    private fun connectThroughChain(chain: List<ProxyHop>, destHost: String, destPort: Int): Socket {
        if (chain.isEmpty()) {
            // No chain configured: connect straight out (still going through the VPN's protected socket).
            val direct = Socket()
            protectSocket(direct)
            direct.connect(InetSocketAddress(destHost, destPort), 15000)
            return direct
        }

        val first = chain.first()
        val sock = Socket()
        protectSocket(sock) // CRITICAL: prevents this outbound socket from being re-captured by the VPN
        sock.connect(InetSocketAddress(first.host, first.port), 15000)
        negotiateHop(sock, first, destHostForNextHop(chain, 0, destHost), destPortForNextHop(chain, 0, destPort))

        for (i in 1 until chain.size) {
            val hop = chain[i]
            val target = destHostForNextHop(chain, i, destHost)
            val targetPort = destPortForNextHop(chain, i, destPort)
            negotiateHopOverExistingSocket(sock, hop, target, targetPort)
        }
        return sock
    }

    // For every hop except the last, the "destination" we ask it to CONNECT to is the NEXT hop's address.
    // For the last hop, the destination is the real target.
    private fun destHostForNextHop(chain: List<ProxyHop>, index: Int, finalHost: String): String =
        if (index == chain.lastIndex) finalHost else chain[index + 1].host

    private fun destPortForNextHop(chain: List<ProxyHop>, index: Int, finalPort: Int): Int =
        if (index == chain.lastIndex) finalPort else chain[index + 1].port

    private fun negotiateHop(sock: Socket, hop: ProxyHop, targetHost: String, targetPort: Int) {
        negotiateHopOverExistingSocket(sock, hop, targetHost, targetPort)
    }

    private fun negotiateHopOverExistingSocket(sock: Socket, hop: ProxyHop, targetHost: String, targetPort: Int) {
        when (hop.type) {
            ProxyType.SOCKS5 -> socks5Connect(sock, hop, targetHost, targetPort)
            ProxyType.HTTP, ProxyType.HTTPS -> httpConnect(sock, hop, targetHost, targetPort)
        }
    }

    private fun socks5Connect(sock: Socket, hop: ProxyHop, targetHost: String, targetPort: Int) {
        val out = DataOutputStream(sock.getOutputStream())
        val inp = DataInputStream(sock.getInputStream())

        val useAuth = !hop.username.isNullOrEmpty()
        out.write(if (useAuth) byteArrayOf(0x05, 0x01, 0x02) else byteArrayOf(0x05, 0x01, 0x00))
        out.flush()
        val verReply = inp.readByte()
        val method = inp.readByte().toInt()
        if (method == 0x02) {
            val u = hop.username!!.toByteArray(Charsets.UTF_8)
            val p = (hop.password ?: "").toByteArray(Charsets.UTF_8)
            out.write(byteArrayOf(0x01, u.size.toByte())); out.write(u)
            out.write(byteArrayOf(p.size.toByte())); out.write(p)
            out.flush()
            inp.readByte(); val status = inp.readByte().toInt()
            if (status != 0x00) throw Exception("SOCKS5 auth failed at ${hop.label}")
        } else if (method != 0x00) {
            throw Exception("No acceptable SOCKS5 auth method for ${hop.label}")
        }

        val hostBytes = targetHost.toByteArray(Charsets.US_ASCII)
        out.write(byteArrayOf(0x05, 0x01, 0x00, 0x03, hostBytes.size.toByte()))
        out.write(hostBytes)
        out.writeShort(targetPort)
        out.flush()

        inp.readByte() // ver
        val rep = inp.readByte().toInt()
        inp.readByte() // rsv
        val atyp = inp.readByte().toInt()
        when (atyp) {
            0x01 -> inp.skipBytes(4)
            0x03 -> inp.skipBytes(inp.readByte().toInt() and 0xFF)
            0x04 -> inp.skipBytes(16)
        }
        inp.readShort()
        if (rep != 0x00) throw Exception("SOCKS5 CONNECT via ${hop.label} failed, code=$rep")
    }

    private fun httpConnect(sock: Socket, hop: ProxyHop, targetHost: String, targetPort: Int) {
        val out = sock.getOutputStream()
        val inp = sock.getInputStream()
        val sb = StringBuilder()
        sb.append("CONNECT $targetHost:$targetPort HTTP/1.1\r\n")
        sb.append("Host: $targetHost:$targetPort\r\n")
        if (!hop.username.isNullOrEmpty()) {
            val cred = Base64.encodeToString("${hop.username}:${hop.password ?: ""}".toByteArray(), Base64.NO_WRAP)
            sb.append("Proxy-Authorization: Basic $cred\r\n")
        }
        sb.append("Connection: Keep-Alive\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.US_ASCII))
        out.flush()

        // Read status line + headers until blank line
        val statusLine = readLine(inp)
        while (readLine(inp).isNotEmpty()) { /* discard headers */ }
        if (!statusLine.contains(" 200 ")) throw Exception("HTTP CONNECT via ${hop.label} failed: $statusLine")
    }

    private fun readLine(inp: InputStream): String {
        val sb = StringBuilder()
        while (true) {
            val b = inp.read()
            if (b == -1 || b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun replySocksFailure(output: DataOutputStream) {
        try { output.write(byteArrayOf(0x05, 0x01, 0x00, 0x01, 0, 0, 0, 0, 0, 0)); output.flush() } catch (_: Exception) {}
    }

    private fun pipe(input: InputStream, output: OutputStream) {
        pool.execute {
            try {
                val buf = ByteArray(8192)
                while (true) {
                    val n = input.read(buf)
                    if (n == -1) break
                    output.write(buf, 0, n)
                    output.flush()
                }
            } catch (_: Exception) {
            } finally {
                try { input.close() } catch (_: Exception) {}
                try { output.close() } catch (_: Exception) {}
            }
        }
    }
}
