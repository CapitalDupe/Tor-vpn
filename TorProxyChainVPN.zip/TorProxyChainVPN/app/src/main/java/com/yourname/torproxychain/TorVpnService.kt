package com.yourname.torproxychain

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.net.ProxyInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.File
import java.net.Socket

/**
 * VPN entry point.
 *
 * Flow:
 *  1. We open a tun interface with VpnService.Builder (all device traffic routes here).
 *  2. We run the local ProxyChainSocksServer on 127.0.0.1:PORT — it knows how to
 *     walk the user's proxy chain and optionally hand off to Orbot's Tor SOCKS port.
 *  3. We hand the tun fd to hev-socks5-tunnel (native binary, started as a child
 *     process with a small YAML config) which converts raw IP packets <-> SOCKS5
 *     against our local server. This native piece is NOT included in this source
 *     drop — see README.md for how to add the prebuilt binary.
 *
 * Sockets created for hop-to-hop connections MUST be protect()'ed or they'd get
 * captured by the tun interface again and loop forever.
 */
class TorVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var chainServer: ProxyChainSocksServer? = null
    private val localChainPort = 1080

    companion object {
        const val CHANNEL_ID = "tor_proxy_chain_vpn"
        const val NOTIF_ID = 1
        var isRunning = false
            private set
    }

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        startVpn()
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "VPN Status", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notif = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Tor Proxy Chain VPN")
            .setContentText("Routing traffic through your configured chain")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun startVpn() {
        val chain = ProxyStore.loadChain(this)

        // 1. Start local SOCKS5 chain relay
        chainServer = ProxyChainSocksServer(
            listenPort = localChainPort,
            getChain = { chain },
            protectSocket = { sock: Socket -> this.protect(sock) },
            onLog = { Log.d("TorVpnService", it) }
        ).also { it.start() }

        // 2. Establish tun interface
        val builder = Builder()
            .setSession("TorProxyChainVPN")
            .addAddress("10.10.10.2", 32)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)

        vpnInterface = builder.establish()
        isRunning = true

        // 3. Hand the tun fd to hev-socks5-tunnel pointed at our local chain server.
        //    See README.md for wiring this native process up — it needs the fd number,
        //    a config file with "socks5: 127.0.0.1:1080", and to run via ProcessBuilder
        //    pointing at the .so placed under jniLibs (Android lets you exec files
        //    inside your own nativeLibraryDir).
        launchTun2Socks()
    }

    private fun launchTun2Socks() {
        try {
            val fd = vpnInterface?.fd ?: return
            val nativeDir = applicationInfo.nativeLibraryDir
            val binary = File(nativeDir, "libhev-socks5-tunnel.so")
            if (!binary.exists()) {
                Log.w("TorVpnService", "hev-socks5-tunnel binary not found at $binary — see README.md")
                return
            }
            val configFile = File(filesDir, "tun2socks.yaml")
            configFile.writeText(
                """
                tunnel:
                  name: tun0
                  mtu: 1500
                  ipv4: 10.10.10.2
                socks5:
                  address: 127.0.0.1
                  port: $localChainPort
                  udp: 'udp'
                misc:
                  log-file: ${filesDir}/tun2socks.log
                  log-level: warn
                """.trimIndent()
            )
            // hev-socks5-tunnel supports taking over an already-open tun fd via --fd
            ProcessBuilder(binary.absolutePath, "--fd", fd.toString(), configFile.absolutePath)
                .redirectErrorStream(true)
                .start()
        } catch (e: Exception) {
            Log.e("TorVpnService", "Failed to launch tun2socks: ${e.message}")
        }
    }

    override fun onDestroy() {
        isRunning = false
        chainServer?.stop()
        try { vpnInterface?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onRevoke() {
        onDestroy()
        super.onRevoke()
    }
}
